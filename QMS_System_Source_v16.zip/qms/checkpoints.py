# -*- coding: utf-8 -*-
"""v16 — (1) نقاط تحقق الجودة بعد كل عملية إنتاج: تسلسل الأرقام والطباعة على البطاقات.
       (2) صندوق مراسلات بين الإدارات: رفع ملاحظة والرد عليها حتى الإغلاق.

كل عملية تُنشئ نقطة تحقق (وإشعارًا واحدًا للجودة). مستخدم الجودة يؤكد سلامة التسلسل وبيانات الطباعة،
وإن وجد خللًا تُفتح تلقائيًا محادثة مع الإنتاج.
"""
from flask import render_template, request, redirect, url_for, flash, abort, g

import db, auth, notify
from util import s

# مفتاح المرحلة: (الاسم، ما يتحقق منه مستخدم الجودة)
STAGES = {
    'slit':      ('القص — بطاقات Sub Roll', 'تسلسل أرقام Sub Roll وبيانات الطباعة على بطاقة كل سب رول (الكود، العرض، الطول، الجامبو، LOT المورد)'),
    'fold':      ('الطي', 'تسلسل سند الطي وبيانات الطباعة على كرتون SP الوسيط (إن وُجد) وربطه بالسب رول'),
    'sp_in':     ('SP وارد من مورّد', 'بيانات الطباعة على كرتون SP الوسيط وربطه بـ LOT المورد'),
    'ns_pack':   ('تعبئة غير المعقم', 'الطباعة على الباكت (100 مسحة) وعلى كرتون التعبئة، وتسلسل رقم السند'),
    'sort':      ('الفرز والعد', 'تسلسل سجل الفرز وأرقام كراتين SP المستهلكة والكمية المقبولة والمرفوضة'),
    'envelope':  ('تغليف المسحات (المغلفات)', 'الطباعة على المغلفات (5 أو 10 مسحات): الكود، LOT، عدد المسحات'),
    'box':       ('البوكسات', 'الطباعة على البوكسات (100 مسحة): الكود، LOT، عدد المغلفات وتسلسل السجل'),
    'pre_ster':  ('قبل التعقيم — الكراتين', 'الطباعة على الكراتين الرئيسية قبل التعقيم وتطابق العدد مع السجل'),
    'ster_cycle': ('دورة التعقيم', 'بيانات الدورة (رقم الدورة، الحمولة، التوقيت) وتطابقها مع طباعة الأغلفة والبوكسات'),
    'post_ster': ('بعد التعقيم والتهوية', 'الطباعة على البوكسات والكراتين بعد التعقيم (رقم الدورة، LOT الغاز) وتسلسل السجل'),
    'fg':        ('كراتين المنتج النهائي', 'الطباعة على كراتين المنتج النهائي (المنتج، LOT، الكمية) قبل الإفراج والتخزين'),
    'sp_pack':   ('تعبئة خط SP', 'رقم سند التعبئة والكميات والطباعة على العبوات'),
    'bandage':   ('خط الأربطة', 'رقم السند والكميات والطباعة على الرولات/العبوات'),
}

DEPTS = {'production': 'الإنتاج', 'quality': 'الجودة', 'warehouse': 'المخزن', 'management': 'الإدارة'}
_DEPT_PERM = {'production': ('enter',), 'quality': ('qc_record',), 'warehouse': ('warehouse',), 'management': ('wo_issue',)}
_ROLE_DEPT = {'operator': 'production', 'qc': 'quality', 'qa': 'quality', 'store': 'warehouse', 'manager': 'management', 'admin': 'management'}


def dept_of(u):
    return _ROLE_DEPT.get(u['role'], 'production')


def add(con, stage, batch_no, ref, detail='', label_kind=None, label_key=None, item_code=None, route=None):
    """نقطة تحقق واحدة لكل (مرحلة، مرجع) قيد الانتظار + إشعار للجودة. تُستدعى داخل تعامل العملية نفسه."""
    from flask import has_request_context
    if con.execute("SELECT 1 FROM qc_checks WHERE stage=? AND ref=? AND status='pending'", (stage, ref)).fetchone():
        return
    who = g.user['username'] if has_request_context() and getattr(g, 'user', None) else 'system'
    cur = con.execute("""INSERT INTO qc_checks(stage,batch_no,ref,item_code,route_code,detail,label_kind,label_key,created_by)
                         VALUES(?,?,?,?,?,?,?,?,?)""", (stage, batch_no, ref, item_code, route, detail, label_kind, label_key, who))
    name = STAGES[stage][0]
    notify.push(con, 'qc_check', f'تحقق الجودة: {name} — {ref}' + (f' (التشغيلة {batch_no})' if batch_no else ''),
                detail or STAGES[stage][1], url_for('qc_check_view', cid=cur.lastrowid), batch_no, route, ('qc_record',))


def open_thread(con, subject, from_dept, to_dept, body, author, batch_no=None, ref=None):
    cur = con.execute("INSERT INTO dept_threads(subject,from_dept,to_dept,batch_no,ref,created_by) VALUES(?,?,?,?,?,?)",
                      (subject, from_dept, to_dept, batch_no, ref, author))
    tid = cur.lastrowid
    con.execute("INSERT INTO dept_messages(thread_id,body,author,dept) VALUES(?,?,?,?)", (tid, body, author, from_dept))
    notify.push(con, 'dept_message', f'ملاحظة جديدة من {DEPTS[from_dept]}: {subject}', body[:200], url_for('msg_view', tid=tid),
                batch_no, None, _DEPT_PERM[to_dept])
    return tid


def _can_see(u, t):
    return u['role'] in ('manager', 'admin') or dept_of(u) in (t['from_dept'], t['to_dept'])


def register(app):
    def route(path, endpoint, **kw):
        def deco(fn):
            app.add_url_rule(path, endpoint, fn, **kw)
            return fn
        return deco

    # ------------------------------------------------------------ تحقق الجودة
    @route('/quality/checks', 'qc_checks')
    def qc_checks():
        st = request.args.get('st') or 'pending'
        if st not in ('pending', 'ok', 'issue'):
            st = 'pending'
        rows = db.q("SELECT * FROM qc_checks WHERE status=? ORDER BY id DESC LIMIT 300", (st,))
        lines = auth.user_lines()
        if lines:
            rows = [r for r in rows if not r['route_code'] or r['route_code'] in lines]
        cnt = {k: db.one('SELECT COUNT(*) n FROM qc_checks WHERE status=?', (k,))['n'] for k in ('pending', 'ok', 'issue')}
        return render_template('qc_checks.html', nav='quality', rows=rows, st=st, cnt=cnt, stages=STAGES)

    @route('/quality/checks/<int:cid>', 'qc_check_view', methods=['GET', 'POST'])
    def qc_check_view(cid):
        c = db.one('SELECT * FROM qc_checks WHERE id=?', (cid,))
        if not c:
            abort(404)
        if c['route_code']:
            auth.need_line(c['route_code'])
        if request.method == 'POST':
            auth.need('qc_record')
            if c['status'] != 'pending':
                flash('تم التحقق من هذه العملية مسبقًا', 'bad')
                return redirect(url_for('qc_check_view', cid=cid))
            f = request.form
            seq_ok, print_ok = bool(f.get('seq_ok')), bool(f.get('print_ok'))
            note = s(f.get('note'))
            ok = seq_ok and print_ok
            if not ok and not note:
                flash('اكتب وصف الخلل ليصل إلى الإنتاج', 'bad')
                return redirect(url_for('qc_check_view', cid=cid))
            with db.tx() as con:
                tid = None
                if not ok:
                    bad = ' و'.join(x for x, v in (('تسلسل الأرقام', seq_ok), ('بيانات الطباعة', print_ok)) if not v)
                    tid = open_thread(con, f'خلل في {bad}: {STAGES[c["stage"]][0]} — {c["ref"]}', 'quality', 'production',
                                      note, g.user['full_name'], c['batch_no'], c['ref'])
                con.execute("""UPDATE qc_checks SET status=?, seq_ok=?, print_ok=?, note=?, checked_by=?, checked_at=datetime('now','localtime'),
                               thread_id=? WHERE id=? AND status='pending'""",
                            ('ok' if ok else 'issue', int(seq_ok), int(print_ok), note, g.user['full_name'], tid, cid))
            db.log('qc_check', 'qc_checks', str(cid), f'{c["stage"]}; {c["ref"]}; {"ok" if ok else "issue"}')
            flash('تم اعتماد التسلسل والطباعة' if ok else 'سُجّل الخلل وأُرسل إلى الإنتاج في صندوق المراسلات', 'ok' if ok else 'warn')
            return redirect(url_for('qc_checks'))
        return render_template('qc_check.html', nav='quality', c=c, stage=STAGES[c['stage']])

    # ------------------------------------------------------------ المراسلات
    @route('/messages', 'msg_list')
    def msg_list():
        u = g.user
        st = request.args.get('st') or 'open'
        if st not in ('open', 'closed'):
            st = 'open'
        rows = [t for t in db.q('SELECT * FROM dept_threads WHERE status=? ORDER BY last_at DESC, id DESC LIMIT 300', (st,)) if _can_see(u, t)]
        for t in rows:
            t['n'] = db.one('SELECT COUNT(*) n FROM dept_messages WHERE thread_id=?', (t['id'],))['n']
        return render_template('msg_list.html', nav='msg', rows=rows, st=st, depts=DEPTS, mine=dept_of(u))

    @route('/messages/new', 'msg_new', methods=['GET', 'POST'])
    def msg_new():
        u = g.user
        if request.method == 'POST':
            auth.need('view')
            f = request.form
            to, subject, body = s(f.get('to_dept')), s(f.get('subject')), s(f.get('body'))
            if to not in DEPTS or not subject or not body:
                flash('اختر الإدارة المستلمة واكتب الموضوع والملاحظة', 'bad')
                return redirect(url_for('msg_new'))
            with db.tx() as con:
                tid = open_thread(con, subject, dept_of(u), to, body, u['full_name'], s(f.get('batch_no')), s(f.get('ref')))
            db.log('create', 'dept_threads', str(tid), subject)
            flash('أُرسلت الملاحظة وأُشعرت الإدارة المستلمة', 'ok')
            return redirect(url_for('msg_view', tid=tid))
        batches = db.q("SELECT batch_no, item_code FROM work_orders WHERE COALESCE(order_type,'إنتاج')='إنتاج' ORDER BY rowid DESC LIMIT 150")
        return render_template('msg_new.html', nav='msg', depts=DEPTS, mine=dept_of(u), batches=batches,
                               b=request.args.get('batch') or '', to=request.args.get('to') or '')

    @route('/messages/<int:tid>', 'msg_view', methods=['GET', 'POST'])
    def msg_view(tid):
        u = g.user
        t = db.one('SELECT * FROM dept_threads WHERE id=?', (tid,))
        if not t or not _can_see(u, t):
            abort(404 if not t else 403)
        if request.method == 'POST':
            auth.need('view')
            act = request.form.get('act') or 'reply'
            body = s(request.form.get('body'))
            other = t['from_dept'] if dept_of(u) == t['to_dept'] else t['to_dept']
            with db.tx() as con:
                if act == 'reply':
                    if not body:
                        flash('اكتب الرد', 'bad')
                        return redirect(url_for('msg_view', tid=tid))
                    con.execute('INSERT INTO dept_messages(thread_id,body,author,dept) VALUES(?,?,?,?)', (tid, body, u['full_name'], dept_of(u)))
                    con.execute("UPDATE dept_threads SET last_at=datetime('now','localtime'), status='open' WHERE id=?", (tid,))
                    notify.push(con, 'dept_message', f'رد من {DEPTS[dept_of(u)]}: {t["subject"]}', body[:200], url_for('msg_view', tid=tid),
                                t['batch_no'], None, _DEPT_PERM[other])
                elif act == 'close':
                    con.execute("UPDATE dept_threads SET status='closed', last_at=datetime('now','localtime') WHERE id=?", (tid,))
                    con.execute('INSERT INTO dept_messages(thread_id,body,author,dept) VALUES(?,?,?,?)',
                                (tid, 'أُغلقت المحادثة' + (f' — {body}' if body else ''), u['full_name'], dept_of(u)))
                    notify.push(con, 'dept_message', f'أُغلقت المحادثة: {t["subject"]}', body[:200], url_for('msg_view', tid=tid),
                                t['batch_no'], None, _DEPT_PERM[other])
                elif act == 'reopen':
                    con.execute("UPDATE dept_threads SET status='open', last_at=datetime('now','localtime') WHERE id=?", (tid,))
            db.log('update', 'dept_threads', str(tid), act)
            return redirect(url_for('msg_view', tid=tid))
        msgs = db.q('SELECT * FROM dept_messages WHERE thread_id=? ORDER BY id', (tid,))
        return render_template('msg_view.html', nav='msg', t=t, msgs=msgs, depts=DEPTS, mine=dept_of(u))
