# -*- coding: utf-8 -*-
"""ترحيل v16 — نقاط تحقق الجودة بعد كل عملية + صندوق المراسلات بين الإدارات. آمن ويمكن تكراره."""
import sqlite3

import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS qc_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stage TEXT NOT NULL, batch_no TEXT, ref TEXT, item_code TEXT, route_code TEXT, detail TEXT,
  label_kind TEXT, label_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending',          -- pending / ok / issue
  created_at TEXT DEFAULT (datetime('now','localtime')), created_by TEXT,
  seq_ok INTEGER, print_ok INTEGER, note TEXT, checked_by TEXT, checked_at TEXT, thread_id INTEGER
);
CREATE INDEX IF NOT EXISTS ix_qcc_status ON qc_checks(status, id);
CREATE INDEX IF NOT EXISTS ix_qcc_batch ON qc_checks(batch_no);
CREATE TABLE IF NOT EXISTS dept_threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject TEXT NOT NULL, from_dept TEXT NOT NULL, to_dept TEXT NOT NULL, batch_no TEXT, ref TEXT,
  status TEXT NOT NULL DEFAULT 'open',              -- open / closed
  created_by TEXT, created_at TEXT DEFAULT (datetime('now','localtime')), last_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS dept_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES dept_threads(id),
  body TEXT NOT NULL, author TEXT, dept TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_dmsg_thread ON dept_messages(thread_id);
"""


def run(verbose=False):
    con = sqlite3.connect(db.DB_PATH, timeout=30)
    try:
        con.executescript(SCHEMA)
        con.commit()
        if verbose:
            print('  اكتمل ترحيل v16 (نقاط تحقق الجودة + المراسلات).')
    finally:
        con.close()


if __name__ == '__main__':
    run(verbose=True)
